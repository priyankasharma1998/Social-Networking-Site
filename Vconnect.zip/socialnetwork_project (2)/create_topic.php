<?php
//create_cat.php
session_start();
if(isset($_SESSION['namei']) && isset($_SESSION['passwo']))
{
//create_cat.php
//include 'connect.php';

//include 'connect.php';
$con=mysqli_connect ("localhost","root","","vconnect");
if (mysqli_connect_errno()) {
echo "failed to connect mysql: ". mysqli_connect_error();
}
include 'header.php';


echo "<h2 style='font-weight:bold ;font-size:25px;color:#b23f05'>Create a topic</h2>";

if(!isset($_SESSION['namei']) || !isset($_SESSION['passwo']))
{
	//the user is not signed in
	echo "sorry you have to be sign in to post to that topic";
}
else
{
	//the user is signed in
	if($_SERVER['REQUEST_METHOD'] != 'POST')
	{	
		//the form hasn't been posted yet, display it
		//retrieve the categories from the database for use in the dropdown
		$sql = "SELECT
					cat_id,
					cat_name,
					cat_description
				FROM
					categories";
		
		$result = mysqli_query($con, $sql);
		
		if(!$result)
		{
			//the query failed, uh-oh :-(
			echo "Error while selecting from database. Please try again later.";
		}
		else
		{
			if(mysqli_num_rows($result) == 0)
			{
				//there are no categories, so a topic can't be posted
				
				{
					echo 'Before you can post a topic, you must wait for an admin to create some categories.';
				}
			}
			else
			{
		
				echo '<form method="post" action="">
					<label  style="font-weight:bold ;font-size:20px;color:#b23e00">Subject: </label><input type="text" name="topic_subject" />
					<label  style="font-weight:bold ;font-size:20px;color:#b23e00">Category:</label>'; 
				
				echo '<select name="topic_cat">';
					while($row = mysqli_fetch_array($result))
					{
						echo "<option value=\"" . $row['cat_id'] . "\">" . $row['cat_name'] . "</option>";
					}
				echo '</select><br>';	
					
				echo '<br><label  style="font-weight:bold ;font-size:20px;color:#b23e00">Message:</label><br> <textarea name="post_content" /></textarea><br>
					<input type="submit" value="Create topic" style="background:#b23e00;font-weight:bold;font-size:15px"/>
				 </form>';
			}
		}
	}
	else
	{
		//start the transaction
		$query  = "BEGIN WORK;";
		$result = mysqli_query($con, $query);
		
		if(!$result)
		{
			//Damn! the query failed, quit
			echo 'An error occured while creating your topic. Please try again later.';
		}
		else
		{
		
	
			//the form has been posted, so save it
			//insert the topic into the topics table first, then we'll save the post into the posts table
			$sql = "INSERT INTO 
                        topics(topic_subject,
                               topic_date,
                               topic_cat,
                               topic_by)
                   VALUES('" . mysql_real_escape_string($_POST['topic_subject']) . "',
                               NOW(),
                               '" . mysql_real_escape_string($_POST['topic_cat']) . "',
                               '" . $_SESSION['first'] . "'
                               )";
					 
			$result = mysqli_query($con, $sql);
			if(!$result)
			{
				//something went wrong, display the error
				echo "An error occured while inserting your data. Please try again later." ;
				$sql = "ROLLBACK;";
				$result = mysql_query($con, $sql);
			}
			else
			{
				//the first query worked, now start the second, posts query
				//retrieve the id of the freshly created topic for usage in the posts query
				$topicid = mysqli_insert_id($con);
				
				$sql = "INSERT INTO
							posts(post_content,
								  post_date,
								  post_topic,
								  post_by)
						 VALUES('" . mysql_real_escape_string($_POST['post_content']) . "',
								  NOW(),
								  '" . $topicid . "',
								  '" . $_SESSION['first'] . "')";
				$result = mysqli_query($con, $sql);
				
				if(!$result)
				{
					//something went wrong, display the error
					echo "An error occured while inserting your post. Please try again later." . mysql_error();
					$sql = "ROLLBACK;";
					$result = mysqli_query($con, $sql);
				}
				else
				{
					$sql = "COMMIT;";
					$result = mysqli_query($con, $sql);
						
					//after a lot of work, the query succeeded!
					echo "You have successfully created a new topic";
				
				}
			}
		}
	}
}
}
//include 'footer.php';
?>