
<?php
session_start();
if(isset($_SESSION['namei']) && isset($_SESSION['passwo']))
{

	$con=mysqli_connect ("localhost","root","","vconnect");
	if (mysqli_connect_errno()) {
	echo "failed to connect mysql: ". mysqli_connect_error();
	}
	include 'header.php';

	if($_SERVER['REQUEST_METHOD'] != 'POST')
	{
	//someone is calling the file directly, which we don't want
		echo 'This file cannot be called directly.';
	}
	else
	{
		//check for sign in status
		if(!isset($_SESSION['namei']) || !isset($_SESSION['passwo']))
		{
			echo 'You must be signed in to post a reply.';
		}
		else
		{

			//a real user posted a real reply
			$sql = "INSERT INTO 
						posts(post_content,
							  post_date,post_topic,post_by) 
					VALUES ('" . $_POST['reply_content'] . "',
						NOW(),'" . $_GET['id'] . "','" . $_SESSION['first'] . "' )";
							
			$result = mysqli_query($con, $sql);
							
			if(!$result)
			{
				echo 'Your reply has not been saved, please try again later.';
			}
			else
			{
				echo '<h2 style="font-size:19px">Your reply has been saved, check out <a href="topic.php?id=' . htmlentities($_GET['id']) . '">the topic</a>.</h2>';
			}
		}
	}
}
//include 'footer.php';
?>